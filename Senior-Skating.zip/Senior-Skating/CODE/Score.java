//Stephanie Colen

   import java.util.*;
   import java.io.*;


   public class Score {
   
      private String element;
      private double score;
   
      public Score(){
         element = "";
         score = 0;
      }
      public Score(String n, double r){
         element = n;
         score = r;
      }
      public Score(String n){
         element = n;
         score = 0;
      }
      public String getElement(){
         return element;
      }
      public double getScore(){
         return score;
      }
      public void setScore(int s){
         score = s;
      }
      public void setName(String s){
         element = s;
      }
   }
