	//Stephanie Colen
	//let only referee add things, then let judges log in
	//referee able to change misspellings and mis-entered elements
	//insert catch for inputs: if error, try again!
	//add in calculations for jump combos and sequences
	
   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
   import java.util.ArrayList;
   import java.util.*;
   import java.io.*;
   public class Panel extends JPanel 
   {
   
      private ArrayList<Skater> skaters = new ArrayList<Skater>();
      private Map<Double,Skater> finalScores = new HashMap<Double,Skater>();
      private ArrayList<Skater> ranks = new ArrayList<Skater>();
      private Map<String, Double> base = new HashMap<String,Double>();
      public ArrayList<Integer> techScores = new ArrayList<Integer>();
      private Scanner sc;
      private PrintStream outfile;
      public ArrayList<JButton> abuttons;
      public ArrayList<JButton> tbuttons;
      public int currentSkater = 0;
      private JLabel label;
      private JLabel label2;
      private JLabel techLabel;
      private JLabel george;
      public JButton names;
      public JButton skills;
      public JButton instructions;
      public JButton quit;
      public int num1 = -2;
      public int currentEl;
      public JFrame myFrame;
      
      public Panel(JFrame frame) throws FileNotFoundException
      {
         myFrame = frame;
         //myFrame.setVisible(true);
         String total = "";
         //later, will allow referee to combine scores of multiple judges by reading in their score files
      	
         /*try{Scanner h = new Scanner(new File("scores.txt"));
            
            while(h.hasNext())
               total += h.next() + " ";
         }
            catch(FileNotFoundException f) {}*/
      		
       //when adding multi-user login, change name of file to reflect judge number
         try{outfile = new PrintStream(new FileOutputStream("scores.txt"));
            outfile.print(total);
            outfile.print("FINAL RANKINGS: ");
         }
            catch(FileNotFoundException f)
            {
            } 
         
         //make continuous
         //while (num1 != -1){ 
         createPanels();
         //}
      }
      //create map of base values of all elements
      public void getBV() throws FileNotFoundException
      {
         Scanner infile = new Scanner(new File("SOV.txt"));
         while(infile.hasNext()){
            String temp = infile.nextLine();
            String el = temp.substring(0, temp.indexOf(" "));
            double score = Double.parseDouble(temp.substring(temp.indexOf(" ")));
            base.put(el, score);
         }
      }
      public void createPanels() throws FileNotFoundException {
         //String login = "Enter judge number. (0 for referee, -1 to quit)";
         //num1 = Integer.parseInt(JOptionPane.showInputDialog(login));
         //if(num1 == 0){ //if referee, display modifying buttons (have a button to allow judging to begin)*/
            										  //and summary of input
         											    
         String message = "Number of skaters?";
         int num = Integer.parseInt(JOptionPane.showInputDialog(message));
            
         getBV();
         addEls(num);
            
         myFrame.setVisible(true);
         setLayout(new GridLayout(2,2));
               
            //button for changing names
            /*names = new JButton("Edit Names");
            names.setEnabled(true);
            names.setPreferredSize(new Dimension(75, 75));
            names.addActionListener(new names());
            //button for changing elements performed
            skills = new JButton("Edit Skills");
            skills.setEnabled(true);
            skills.setPreferredSize(new Dimension(75, 75));
            skills.addActionListener(new skills());
            //button to return to home screen
            quit = new JButton("Quit");
            quit.setEnabled(true);
            quit.setPreferredSize(new Dimension(75, 75));
            quit.addActionListener(new quit());
            //button to display simple explanation
            instructions = new JButton("Instructions");
            instructions.setEnabled(true);
            instructions.setPreferredSize(new Dimension(75, 75));
            instructions.addActionListener(new instructions());
            this.add(names);
            this.add(skills);
            this.add(instructions);
            this.add(quit);
         }
         else{ //if judge, display score selection screen
            if(skaters.size() == 0){
               String message = "You have not entered any skaters. Ask the referee to add the skaters.";
               JOptionPane.showMessageDialog(null, message);
               createPanels();
            }
            else{*/
         JPanel myPanel = new JPanel();
         System.out.println("message!");
               /*String*/ message = "Choose one score for the artistic component of the score and one GOE for each element the skater performs. The \n computer will autmoatically calculate the score and rank the skaters once all have performed.";
         JOptionPane.showMessageDialog(null, message);  
            
         myFrame.setVisible(true);
         setLayout(new BorderLayout());
            
         System.out.println("current skater label");
         JPanel north = new JPanel();
         north.setLayout(new FlowLayout());
         george = new JLabel("Current skater: " + skaters.get(currentSkater).getName());
         JOptionPane.showMessageDialog(null, message); 
         george.setFont(new Font(george.getFont().getName(), Font.BOLD, 20));
         north.add(george);
         myPanel.add(north, BorderLayout.NORTH); 
            
         System.out.println("tech stuff");
            //technical component   
         JPanel center = new JPanel();
         center.setLayout(new BorderLayout());
         myPanel.add(center, BorderLayout.SOUTH);
            
         label2 = new JLabel("Technical component:");
         label2.setFont(new Font(george.getFont().getName(), Font.PLAIN, 15));
         currentEl = 0;
         techLabel = new JLabel("Current element is: " + skaters.get(currentSkater).getScores().get(currentEl).getElement());
         techLabel.setHorizontalAlignment(SwingConstants.CENTER);
            
         JPanel temp = new JPanel();
         temp.setLayout(new GridLayout(2, 1));
         temp.add(label2);
         temp.add(techLabel);
            
         center.add(temp, BorderLayout.NORTH);
            
         JPanel techButtons = new JPanel();
         techButtons.setLayout(new FlowLayout());
         center.add(techButtons, BorderLayout.CENTER);
            
         tbuttons  = new ArrayList<JButton>();   
         for(int x = -3; x < 4; x++)
         {
            tbuttons.add(new JButton("" + x));
            tbuttons.get(x+3).setEnabled(true);
            tbuttons.get(x+3).setPreferredSize(new Dimension(75, 75));
            tbuttons.get(x+3).addActionListener(new Handler1(Integer.parseInt(tbuttons.get(x+3).getText())));
            if(x != 0){
               techButtons.add(tbuttons.get(x+3)); }
            else {
               techButtons.add(new JPanel());
               techButtons.add(tbuttons.get(x+3));
               techButtons.add(new JPanel());
            }
         }
            
         JPanel south = new JPanel();
         south.setLayout(new BorderLayout());
         myPanel.add(south, BorderLayout.CENTER);
         label = new JLabel("Artistic component:");
         label.setFont(new Font(george.getFont().getName(), Font.PLAIN, 15));
         south.add(label, BorderLayout.NORTH);
            
         JPanel artisticButtons = new JPanel();
         artisticButtons.setLayout(new FlowLayout());
         south.add(artisticButtons, BorderLayout.CENTER);
            
         abuttons  = new ArrayList<JButton>();   
         for(int x = 1; x < 11; x++)
         {
            abuttons.add(new JButton("" + x));
            abuttons.get(x-1).setEnabled(false);
            abuttons.get(x-1).setPreferredSize(new Dimension(50, 50));
            abuttons.get(x-1).addActionListener(new Handler(Integer.parseInt(abuttons.get(x-1).getText())));
            artisticButtons.add(abuttons.get(x-1));
         }
         add(myPanel);
            //}
         //}
      }
      //rank skaters once all have skated
      public void rank()
      {
         for(Skater s : skaters)
         {
            double inte = s.getFinal(base);
            finalScores.put(inte, s);
         }
         double max = 0;
         Skater maxSkater = new Skater();
         while(!finalScores.isEmpty())
         {
            for(double d : finalScores.keySet())
            {
               if (d > max)
               {
                  max = d;
                  maxSkater = finalScores.get(d);
               }
            }
            ranks.add(maxSkater);
            finalScores.remove(max);
            max = 0;   
         }
      }
      //add elements to be performed (initially)
      public void addEls(int num2)
      {
         for(int x = 0; x < num2; x++)
         {
            String askname = "What is skater " + (x+1) + "'s name?";
            String name = "" + JOptionPane.showInputDialog(askname);
            skaters.add(new Skater(name));
            ArrayList<String> elements = new ArrayList<String>();
            String asknumel = "How many elements will " + skaters.get(x).getName() + " perform?";
            int numel = Integer.parseInt("" + JOptionPane.showInputDialog(asknumel));
            for(int y = 0; y < numel; y++)
            {
               String askel = "What element?";
               String element = "" + JOptionPane.showInputDialog(askel);
               while (!base.containsKey(element))
               {
                  element = JOptionPane.showInputDialog("Invalid element. Try again. What element?");
               }
               elements.add(element);
            }
            skaters.get(x).setElements(elements);
         }
      }
      //changing names button handler
      private class names implements ActionListener
      { 
         public names()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            int contAsk = 0;
            while(contAsk != -1){
               String ask = "What name is wrong? Enter a number corresponding to the incorrect name. Enter -1 to finish. \n" ;
               int elNum = 1;
               for(Skater s : skaters)
               {
                  ask += "\n" + elNum + ". " + s.getName();
                  elNum+=1;
               }
               contAsk = Integer.parseInt(JOptionPane.showInputDialog(ask));
               if (contAsk != -1){
                  String newName = JOptionPane.showInputDialog("Enter corrected name.");
                  skaters.get(contAsk-1).setName(newName);
               }
            }
         }
      }
      private class quit implements ActionListener { 
         public quit()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            myFrame.setVisible(false);
            try{createPanels();}
               catch (FileNotFoundException f){}
         }
      }
      //changing skills button handler
      private class skills implements ActionListener
      { 
         public skills()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            int contAsk = 0;
            while(contAsk != -1){
               String ask = "What skater's elements are wrong? Enter a number corresponding to the skater's \n elements you wish to change. Enter -1 to finish. \n" ;
               int elNum = 1;
               for(Skater s : skaters)
               {
                  ask += "\n" + elNum + ". " + s.getName() + "(";
                  for(Score t : skaters.get(elNum-1).getScores()){
                     if(elNum != skaters.size()){
                        ask += t.getElement() + ", ";
                     }
                     else{
                        ask += t.getElement() + ")";
                     }
                  }
                  elNum+=1;
               }
               contAsk = Integer.parseInt(JOptionPane.showInputDialog(ask));
               if (contAsk != -1){
                  ask = "";
                  elNum = 1;
                  for(Score s : skaters.get(elNum-1).getScores()){
                     ask += "\n" + elNum + ". " + s.getElement();
                     elNum+=1;  
                  }
                  int changeEl = Integer.parseInt(JOptionPane.showInputDialog("Enter mumber of element to replace." + ask)); 
                  String newEl = JOptionPane.showInputDialog("Enter new element.");
                  skaters.get(contAsk-1).getScores().get(changeEl-1).setName(newEl);
               }
            }
         }
      }
      //(referee) instruction button handler
      private class instructions implements ActionListener
      {
         public instructions(){
         }
         public void actionPerformed(ActionEvent e)
         {
            String message = "Choose one score for the artistic component of the score and one GOE for each element the skater performs. The \n computer will autmoatically calculate the score and rank the skaters once all have performed.";
            JOptionPane.showMessageDialog(null, message);  
         }
      }
      //technical buttons handler
      private class Handler1 implements ActionListener
      {
         private int myScore;
          
         public Handler1(int r)
         {
            myScore = r;
         }
         public void actionPerformed(ActionEvent e)
         {
            techScores.add(myScore);
            if(currentEl == skaters.get(currentSkater).getScores().size() - 1)
            {
               for(int x = 1; x < 11; x++)
               {
                  abuttons.get(x-1).setEnabled(true);
               }
               for(int x = -3; x < 4; x++)
               {
                  tbuttons.get(x+3).setEnabled(false);
               }
               techLabel.setText("");
               System.out.println(techScores);
               skaters.get(currentSkater).setTech(techScores);
               techScores = new ArrayList<Integer>();
            }
            else
            {
               currentEl += 1;
               techLabel.setText("Current element is: " + skaters.get(currentSkater).getScores().get(currentEl).getElement());
            }
         }
      }
      //artistic buttons handler
      private class Handler implements ActionListener
      {
         private int myScore;
          
         public Handler(int r)
         {
            myScore = r;
         }
         public void actionPerformed(ActionEvent e)
         {
            skaters.get(currentSkater).setArtistic(myScore);
            String current = "Artistic: " + myScore;
            for(Score s : skaters.get(currentSkater).getScores())
            {
               current += "\n" + s.getElement() + "\t \t" + s.getScore();
            }
            current += "\n\n" + "Are these scores correct? You will not be able to \n change these scores once you say yes. Press 1 if these scores are correct \n and 2 if you need to make changes.";
            String changeMe = JOptionPane.showInputDialog(current);
            if(changeMe.equals("1")){
            //do nothing
            }
            else if(changeMe.equals("2")){
            //let judges change scores
               changeScores();
            }
            for(JButton j : abuttons)
            {
               j.setEnabled(false);
            }
            for(JButton j : tbuttons)
            {
               j.setEnabled(true);
            }
            currentEl = 0;
            System.out.println(skaters.get(currentSkater).toString());
            if (currentSkater < skaters.size() - 1)
            {
               currentSkater += 1;
               george.setText("Current skater: " + skaters.get(currentSkater).getName());
               techLabel.setText("Current element: " + skaters.get(currentSkater).getScores().get(currentEl).getElement());
            }
            else{
               JOptionPane.showMessageDialog(null, "All skaters have performed. Computer will automatically rank the skaters.");
               rank();
               String rankings = "FINAL RANKINGS: \n";
               for(int x = 0; x < ranks.size(); x++)
               {
                  rankings += (x+1) + ". " + ranks.get(x).getName() + "\t \t \t" + ranks.get(x).getScore();
               }
               JOptionPane.showMessageDialog(null, rankings);
               outfile.print(rankings.substring(rankings.indexOf(":") + 1));
               System.exit(0);
            }
         }
         public void changeScores(){
         //allow for changing of certain scores
            int contAsk = 0;
            while(contAsk != -1){
               String ask = "What score is wrong? Enter a number corresponding to the incorrect score. Enter -1 to finish. \n" ;
               ask += "Artistic (enter 0): " + myScore;
               int elNum = 1;
               for(Score s : skaters.get(currentSkater).getScores())
               {
                  ask += "\n" + elNum + ". " + s.getElement() + "\t \t" + s.getScore();
                  elNum+=1;
               }
               contAsk = Integer.parseInt((JOptionPane.showInputDialog(ask)));
               if (contAsk != -1){
                  int newScore = Integer.parseInt((JOptionPane.showInputDialog("Enter corrected score.")));
                  if(contAsk > 1){
                     skaters.get(currentSkater).getScores().get(contAsk-1).setScore(newScore);
                  }
                  else{
                     skaters.get(currentSkater).setArtistic(newScore);
                  }
               }
            }
         }
      }
   }