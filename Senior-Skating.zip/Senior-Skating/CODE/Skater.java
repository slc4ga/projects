//Stephanie Colen 

   import java.util.*;
   import java.io.*;


   public class Skater {
   
      private String name;
      private ArrayList<Score> scores = new ArrayList<Score>();
      private Score artistic;
      private ArrayList<Score> finalScores = new ArrayList<Score>();
      private double finalS = 0;
   
      public Skater(){
         name = "";
         artistic = new Score("artistic", 0);
      }
      public Skater(String n){
         name = n;
         artistic = new Score("artistic", 0);
      }
      public Skater(String n, ArrayList<String> s){
         name = n;
         for(String element : s){
            scores.add(new Score(element, 0));
         }	
         artistic = new Score("artistic", 0);
      }
      public String getName(){
         return name;
      }
      public ArrayList<Score> getScores(){
         return scores;
      }
      public void setName(String n){
         name = n;
      }
      public void setElements(ArrayList<String> s){
         for(String element : s){
            scores.add(new Score(element, 0));
         }
         artistic = new Score("artistic", 0);
      }
      public void setArtistic(int x){
         artistic.setScore(x);
      }
      public void setTech(ArrayList<Integer> x){
         for(int s = 0; s < scores.size(); s++)
         {
            scores.get(s).setScore(x.get(s));
         }
      }
      public String toString(){
         String temp = "";
         for(Score s : scores)
         {
            temp = temp + (s.getElement() + "(" + s.getScore() + ")" + "; ");
         }
         return name + ": " + temp + ("artistic (" + artistic.getScore() + ")" + "TOTAL: " + finalS);
      }
      public double getFinal(Map<String,Double> base){
         double finalScore = artistic.getScore();
         finalScores.add(new Score("Artistic", artistic.getScore()));
         for(Score s : scores)
         {
         //if GOE for element = 0; just use BV
            if (s.getScore() == 0){
               finalScores.add(new Score(s.getElement(), base.get(s.getElement())));
               finalScore = finalScore + base.get(s.getElement());
            }
         //if GOE > 0; use BV + GOE
            if (s.getScore() > 0){
               finalScores.add(new Score(s.getElement(), (base.get(s.getElement()) + s.getScore())));
               finalScore = finalScore + base.get(s.getElement()) + s.getScore();
            }
         //if GOE < 0; use BV - .1*GOE
            if (s.getScore() < 0){
               finalScores.add(new Score(s.getElement(), (base.get(s.getElement()) - (.1*s.getScore()))));
               finalScore = finalScore + base.get(s.getElement()) - (.1*s.getScore());
            }
         }
         finalS = finalScore;
         return finalScore;
      }
      public ArrayList<Score> getFinalScores(){
         return finalScores;
      }
      public double getScore(){
         return finalS;
      }
      public void addScore(Score s){
         scores.add(s);
      }
       public void removeScore(Score e)
      {
         int toRemove = -1;
         for(int x = 0; x < scores.size(); x++)
         {
            if(e.getElement().equals(scores.get(x).getElement()))
            {
               toRemove = x;
            }
         }
         scores.remove(toRemove);
      }

   }