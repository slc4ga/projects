//Stephanie Colen 

   import java.util.*;
   import java.io.*;


   public class Competition {
   
      private String name;
      private ArrayList<Event> events = new ArrayList<Event>();
   
      public Competition(){
         name = "";
      }
      public Competition(String n){
         name = n;
      }
      public Competition(String n, ArrayList<String> s){
         name = n;
         for(String element : s){
            events.add(new Event(element, this));
         }	
      }
      public String getName(){
         return name;
      }
      public ArrayList<Event> getEvents(){
         return events;
      }
      public void setName(String n){
         name = n;
      }
      public void setEvents(ArrayList<String> s){
         for(String element : s){
            events.add(new Event(element, this));
         }
      }
      public void addEvent(Event e){
         events.add(e);
      }
      public String toString(){
         String temp = "";
         for(Event s : events)
         {
            temp = temp + s.getName();
         }
         return name + ": " + temp;
      }
      public void removeEvent(Event e)
      {
         int toRemove = -1;
         for(int x = 0; x < events.size(); x++)
         {
            if(e.getName().equals(events.get(x).getName()))
            {
               toRemove = x;
            }
         }
         events.remove(toRemove);
      }
   }