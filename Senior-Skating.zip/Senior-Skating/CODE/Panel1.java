//Stephanie Colen
//INTERWEBS

   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
   import java.util.ArrayList;
   import java.util.*;
   import java.io.*;
   import javax.swing.event.*;
   import java.sql.*;

   public class Panel1 extends JPanel
   {
      public Connection myConn;
      
      public DefaultListModel labels = new DefaultListModel();
      public DefaultListModel labels1 = new DefaultListModel();
      public DefaultListModel labels2 = new DefaultListModel();
      public DefaultListModel labels3 = new DefaultListModel();
      
      public String user;
      public JTextField username;
      public JLabel title;
      public JPanel mid;
   		
      public Competition currentComp;
      public Event currentEvent;
      public Skater currentSkater;
      public Score currentScore;
      public int curScore;
      public JComboBox judgeList;
      public JComboBox compList;
      public JComboBox eventList;
      public JButton addj;
      public JButton addj2;
      public JButton addj3;
      public JButton changePass;
      public JButton removej;
      public JButton checkLogin;
      public JPasswordField oldpass;
      public JPasswordField newpass1;
      public JPasswordField newpass2;
      public ArrayList<JButton> abuttons;
      public ArrayList<JButton> tbuttons;
      public JPanel loginPanel;
      public JPanel refPanel;
      public JPanel judgePanel;
      public JTextArea skatersList;
      public JTextArea elsList;
      public JLabel cSkater;
      public JLabel cEl;
   
      
      public ArrayList<Competition> compsArray = new ArrayList<Competition>();
      public ArrayList<Judge> judgeArray = new ArrayList<Judge>();
      private Map<String, Double> base = new HashMap<String,Double>();
      private Map<Double,Skater> finalScores = new HashMap<Double,Skater>();
      private ArrayList<Skater> ranks = new ArrayList<Skater>();
      public ArrayList<Integer> techScores = new ArrayList<Integer>();
      public ArrayList<String> judges = new ArrayList<String>();
      public String[] comps = {"May Day", "Chesapeake", "Hershey"};
      public String[] events = {"Int Ladies Long", "Int Ladies Short", "Juvenile Girls"};  
      public String[] skaters = {"Stephanie Colen", "Hailey Johnson", "Catherine Dworak", "Lucia Melgarejo"};
   	
      public Frame myFrame;
      public JPasswordField pass;
   
      public Panel1(Frame f, Connection c) throws FileNotFoundException
      {
         myFrame = f;
         myConn = c;
      	
         loginPanel = new JPanel();
         loginPanel.setLayout(new BorderLayout());
         refPanel = new JPanel();
         refPanel.setLayout(new BorderLayout());
         refPanel.setPreferredSize(new Dimension(700, 300));
         judgePanel = new JPanel();
         judgePanel.setLayout(new BorderLayout());
         judgePanel.setPreferredSize(new Dimension(700, 300));
      	
         add(loginPanel);
         add(refPanel);
         add(judgePanel);   
      
         getBV();
         
         login();
      }
      public void login()
      {
         compsArray = new ArrayList<Competition>();
         try{
            ResultSet comps = myConn.createStatement().executeQuery("select * from `competition` order by `name`");
            while(comps.next())
            {
               Competition c = new Competition(comps.getString("name"));
               try{
                  ResultSet events = myConn.createStatement().executeQuery("select * from `events` where `competition_id` = '" + comps.getInt("id") + "'");
                  while(events.next())
                  {
                     Event e = new Event(events.getString("name"), c);
                     try{
                        ResultSet skaters = myConn.createStatement().executeQuery("select * from `skaters` where `event_id` = '" + events.getInt("id") + "'");
                        while(skaters.next())
                        {
                           Skater sk = new Skater(skaters.getString("name"));
                           try{
                              ResultSet scores = myConn.createStatement().executeQuery("select * from `scores` where `skater_id` = '" + skaters.getInt("id") + "'");
                              while(scores.next())
                              {
                                 Score sc = new Score(scores.getString("element_name"));
                                 if(!sk.getScores().contains(sc)){
                                    sk.addScore(sc);
                                 }
                              }
                           }
                              catch (Exception err) {  }
                           if(!e.getSkaters().contains(sk)){
                              e.addSkater(sk); 
                           }
                        }
                     }
                        catch (Exception err) { }
                     if(!c.getEvents().contains(e)){
                        c.addEvent(e);
                     }
                  }
               }
                  catch (Exception err) {  }
               compsArray.add(c);
            }
         }
            catch (Exception err) {  }
            
         try{
            ResultSet judgeRS = myConn.createStatement().executeQuery("select * from `users` order by `name`");
            while(judgeRS.next())
            {
               ResultSet eventRS = myConn.createStatement().executeQuery("select * from `judge_events` where `judge_id` = '" + judgeRS.getInt("id") + "'");
               Judge j = new Judge(judgeRS.getString("name"), judgeRS.getString("username"), judgeRS.getString("password"));
               judgeArray.add(j);
               judges.add(j.getName());
               while(eventRS.next())
               {
                  ResultSet eventsFORREAL = myConn.createStatement().executeQuery("select * from `events` where `id` = " + eventRS.getInt("event_id"));
                  while(eventsFORREAL.next())
                  {
                     ResultSet compRS = myConn.createStatement().executeQuery("select * from `competition` where `id` = '" + eventsFORREAL.getInt("competition_id") + "'");
                     while(compRS.next())
                     {
                        String name = compRS.getString("name");
                        for(Competition c : compsArray)
                        {
                           if(c.getName().equals(name))
                           {
                              for(Event ev : c.getEvents())
                              {
                                 if(ev.getName().equals(eventsFORREAL.getString("name")))
                                 {
                                    if(!j.getEvents().contains(ev)){
                                       j.addEvent(ev);
                                    }
                                 }
                              }
                           }
                        }
                     }
                  }
               }
            }
         }
            catch(Exception err) {  }
      
         remove(refPanel);
         remove(judgePanel);
         add(loginPanel);
         myFrame.setSize(300, 150);
         pass = new JPasswordField(10);
         pass.setText("");
         JLabel askuser = new JLabel("Username: ", SwingConstants.RIGHT);
         JLabel askpass = new JLabel ("Password: ", SwingConstants.RIGHT);
         username = new JTextField(10);
         username.setText("");
         title = new JLabel("LOGIN", SwingConstants.CENTER);
         title.setFont(new Font(title.getFont().getName(), Font.BOLD, 20));
         loginPanel.add(title, BorderLayout.NORTH);
         mid = new JPanel();
         mid.setLayout(new GridLayout(2, 3));
         mid.add(askuser);
         mid.add(username);
         checkLogin = new JButton ("Go");
         checkLogin.setVisible(true);
         checkLogin.setEnabled(true);
         checkLogin.addActionListener(new go());
         mid.add(new JPanel());
         mid.add(askpass);
         mid.add(pass);
         mid.add(checkLogin);
         loginPanel.add(mid, BorderLayout.CENTER);
         pass.selectAll();
         resetFocus();  
         username.selectAll();
         username.requestFocusInWindow();
      }
      protected void resetFocus() {
         pass.requestFocusInWindow();
      }
      public void refereePanel(){
         
         myFrame.setSize(800,400);
         add(refPanel);
         remove(judgePanel);
         remove(loginPanel);
      	
         JPanel top = new JPanel();
         top.setLayout(new FlowLayout());
      
         JButton instructions = new JButton("Instructions");
         instructions.setVisible(true);
         instructions.addActionListener(new instructions());
         JButton logout = new JButton("Logout");
         logout.addActionListener(new logout());
         logout.setVisible(true);
         JLabel welcome = new JLabel("Welcome!");
         JLabel pos = new JLabel("(referee)");
         pos.setFont(new Font(pos.getFont().getName(), Font.ITALIC, 10));
         top.add(welcome);
         top.add(instructions);
         top.add(logout);
         top.add(pos);
         refPanel.add(top, BorderLayout.NORTH);
         
         JPanel middle = new JPanel();
         middle.setLayout(new GridLayout(3, 4));
         middle.add(new JLabel("Competition"));
         middle.add(new JLabel("Event"));
         middle.add(new JLabel("Skater"));
         middle.add(new JLabel("Element"));
         
         for(Competition c: compsArray)
         {
            labels.addElement(c.getName());
         }
         JList comp = new JList(labels);
         comp.addListSelectionListener(new compSelect());
         comp.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         JScrollPane comp1 = new JScrollPane(comp);
         middle.add(comp1, BorderLayout.CENTER);  
        
         JList event = new JList(labels1);
         event.addListSelectionListener(new eventSelect());
         event.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         JScrollPane event1 = new JScrollPane(event);
         middle.add(event1, BorderLayout.CENTER);
           
         JList skater = new JList(labels2);
         skater.addListSelectionListener(new skaterSelect());
         skater.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         JScrollPane skater1 = new JScrollPane(skater);
         middle.add(skater1, BorderLayout.CENTER);
          
         JList els = new JList(labels3);
         els.addListSelectionListener(new elsSelect());
         els.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
         JScrollPane els1 = new JScrollPane(els);
         middle.add(els1, BorderLayout.CENTER);
         
         for(int x = 0; x < 4; x++)
         {
            JPanel temp = new JPanel();
            temp.setLayout(new FlowLayout());
            JButton add = new JButton("Add");
            temp.add(add);
            JButton remove = new JButton("Remove");
            if(x == 0){
               add.addActionListener(new addComp());
               remove.addActionListener(new removeComp()); }
            if(x == 1){
               add.addActionListener(new addEvent()); 
               remove.addActionListener(new removeEvent());
            }
            if(x == 2){
               add.addActionListener(new addSkater());
               remove.addActionListener(new removeSkater()); 
            }
            if(x == 3){
               add.addActionListener(new addEls());
               remove.addActionListener(new removeEls()); 
            }
            temp.add(remove);
            middle.add(temp);
         }
         refPanel.add(middle, BorderLayout.CENTER);
         
      	//create bottom section
         JPanel bottom = new JPanel();
         bottom.setLayout(new GridLayout(2, 1));
      
         JPanel temp = new JPanel();
         
         JLabel setj = new JLabel("Set judge for selected event: ");
         temp.add(setj);
         
         judgeList = new JComboBox(judges.toArray());
         judgeList.setEnabled(false);
         temp.add(judgeList);
      	
         addj = new JButton("Add selected judge to event");
         addj.setVisible(true);
         addj.setEnabled(false);
         addj.addActionListener(new addJudgeToEvent());
         temp.add(addj);
         bottom.add(temp);
         
         JPanel temp2 = new JPanel();
         addj2 = new JButton("Add new judge to selection list");
         addj2.setVisible(true);
         addj2.setEnabled(false);
         addj2.addActionListener(new addJudge());
         temp2.add(addj2);
         
         addj3 = new JButton("View selected judge's current event list.");
         addj3.setVisible(true);
         addj3.setEnabled(false);
         addj3.addActionListener(new viewSelectedEventsList());
         temp2.add(addj3);
         bottom.add(temp2);
         
         removej = new JButton("Remove event from judge's event list");
         removej.setVisible(true);
         removej.setEnabled(false);
         removej.addActionListener(new removeJudgeFromSelectedEvent());
         temp2.add(removej);
         
         changePass = new JButton("Change selected judge's password");
         changePass.setVisible(true);
         changePass.setEnabled(false);
         changePass.addActionListener(new changePassword());
         temp.add(changePass);
      	
         refPanel.add(bottom, BorderLayout.SOUTH);
      }
      public void judgePanel() throws Exception
      {
      //reset size
         myFrame.setSize(800,400);
         add(judgePanel);
         remove(refPanel);
         remove(loginPanel);
      
      //create top labels and buttons and selection boxes
         JPanel top = new JPanel();
         top.setLayout(new GridLayout(2, 1));
      
         JPanel temp = new JPanel();
         JButton instructions = new JButton("Instructions");
         instructions.setVisible(true);
         instructions.addActionListener(new instructions());
         JButton logout = new JButton("Logout");
         logout.addActionListener(new logout());
         logout.setVisible(true);
         JLabel welcome = new JLabel("Welcome!");
         JLabel pos = new JLabel("(judge)");
         pos.setFont(new Font(pos.getFont().getName(), Font.ITALIC, 10));
         
         JPanel temp1 = new JPanel();
         
         compList = new JComboBox(comps);
         compList.setEnabled(true);
         compList.addActionListener(new selectComp());
         temp1.add(compList);
      	
         eventList = new JComboBox(events);
         eventList.setEnabled(false);
         eventList.addActionListener(new selectEvent());
         temp1.add(eventList);
         
         temp.add(welcome);
         temp.add(instructions);
         temp.add(logout);
         temp.add(pos);
         
         top.add(temp);
         top.add(temp1);
         judgePanel.add(top, BorderLayout.NORTH);
      	
      	//create middle (list of elements, add action listeners
         JPanel center = new JPanel();
         center.setLayout(new GridLayout(1, 3));
         judgePanel.add(center, BorderLayout.CENTER);
      	
         JPanel techButtons = new JPanel();
         techButtons.setLayout(new FlowLayout());
          
         JPanel temp3 = new JPanel(new BorderLayout());
         cSkater = new JLabel("Skater Number: ");
         JPanel temp4 = new JPanel(new BorderLayout());
         cEl = new JLabel("Element Number: ");
         JPanel currentLabels = new JPanel(new GridLayout(1, 2));
         currentLabels.add(cSkater);
         currentLabels.add(cEl);
         temp3.add(temp4, BorderLayout.NORTH);
         temp4.add(currentLabels, BorderLayout.NORTH);
         temp4.add(new JLabel("Pick element GOE: "), BorderLayout.CENTER);
      
         JPanel bottom = new JPanel();
         bottom.setLayout(new BorderLayout());
      	
         tbuttons  = new ArrayList<JButton>();   
         for(int x = -3; x < 4; x++)
         {
            tbuttons.add(new JButton("" + x));
            tbuttons.get(x+3).setEnabled(true);
            tbuttons.get(x+3).setPreferredSize(new Dimension(50, 50));
            tbuttons.get(x+3).addActionListener(new Handler1(Integer.parseInt(tbuttons.get(x+3).getText()))); 
            techButtons.add(tbuttons.get(x+3));   
         }
         JPanel skaterList = new JPanel();
         skaterList.setLayout(new FlowLayout());
         String s = "";	
         //make scrollable
         skatersList = new JTextArea(s);
         skatersList.setLineWrap(true);
         skatersList.setEditable(false);
         skatersList.setPreferredSize(new Dimension(200, 200));
         skaterList.add(skatersList);
         center.add(skaterList);
      	
         JPanel elList = new JPanel();
         elList.setLayout(new FlowLayout());
         s = "";
      	
         elsList = new JTextArea(s);
         elsList.setLineWrap(true);
         elsList.setEditable(false);
         elsList.setPreferredSize(new Dimension(200, 200));
         elList.add(elsList);
         center.add(elList);
      	
         temp3.add(techButtons, BorderLayout.CENTER);
         center.add(temp3);
         
         JPanel firstBottom = new JPanel(new FlowLayout());
         JPanel temp5 = new JPanel(new BorderLayout());
         bottom.add(firstBottom);
         abuttons  = new ArrayList<JButton>();  
         JPanel temp2 = new JPanel(new FlowLayout()); 
      
         for(int x = 1; x < 11; x++)
         {
            abuttons.add(new JButton("" + x));
            abuttons.get(x-1).setEnabled(false);
            abuttons.get(x-1).setPreferredSize(new Dimension(50, 50));
            abuttons.get(x-1).addActionListener(new Handler(Integer.parseInt(abuttons.get(x-1).getText())));
            temp2.add(abuttons.get(x-1));
         }
         temp5.add(temp2, BorderLayout.CENTER);
         temp5.add(new JLabel("Pick artistic score: "), BorderLayout.NORTH);
         firstBottom.add(temp5);
         judgePanel.add(bottom, BorderLayout.SOUTH);
      }
      private class selectComp implements ActionListener { // for judge panel
         public selectComp()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            JComboBox cb = (JComboBox)(e.getSource());
            String compName = (String)cb.getSelectedItem();
            Competition sComp = null;
            for(Competition c : compsArray)
            {
               if(c.getName().equals(compName))
               {
                  sComp = c;
                  currentComp = c;
               }
            }
            eventList.setEnabled(true);
            eventList.removeAllItems();
            for(Event ev : sComp.getEvents())
            {
               eventList.addItem(ev.getName());
            }
         }
      }
      private class selectEvent implements ActionListener { // for judge panel
         public selectEvent()
         {
         }
         public void actionPerformed(ActionEvent e) 
         {
            JComboBox cb = (JComboBox)(e.getSource());
            String eventName = (String)cb.getSelectedItem();
            Event sEvent = null;
            for(Event c : currentComp.getEvents())
            {
               if(c.getName().equals(eventName))
               {
                  sEvent = c;
               }
            }
            currentEvent = sEvent;
            String s = "";
            if(sEvent != null)
            {
               for(int x = 0; x < sEvent.getSkaters().size(); x++)
               {
                  s+= (x+1) + ". " + sEvent.getSkaters().get(x).getName() + " \n";
               }
               skatersList.setText(s);
               Skater sk = sEvent.getSkaters().get(0);
               currentSkater = sk;
               s = "";
               for(int x = 0; x < sk.getScores().size(); x++)
               {
                  s+= (x+1) + ". " + sk.getScores().get(x).getElement() + " \n";
               }
               elsList.setText(s);
            
               cSkater.setText("Skater Number: 1");
               cEl.setText("Element Number: 1");
            }
         }
      }
      private class compSelect implements ListSelectionListener { //for referee panel
         public compSelect()
         {
         }
         public void valueChanged(ListSelectionEvent e)
         {
            labels1.clear();
            if (!e.getValueIsAdjusting()) {
               JList list = (JList)e.getSource();
               Object[] selected = list.getSelectedValues();
               String s = "";
               if(selected.length > 0)
                  s = "" + selected[0];
               for(Competition c : compsArray)
               {   
                  if(c.getName().equals(s))
                  {  
                     for(Event t : c.getEvents())
                     {
                        labels1.addElement(t.getName());
                     }
                     currentComp = c;
                  }
               }
            }
         }
      }
      private class eventSelect implements ListSelectionListener {
         public eventSelect()
         {
         }
         public void valueChanged(ListSelectionEvent e)
         {
            if(currentComp != null)
            {
               judgeList.setEnabled(true);
               addj.setEnabled(true);
               addj2.setEnabled(true);
               addj3.setEnabled(true);
               removej.setEnabled(true);
               changePass.setEnabled(true);
               labels2.clear();
               if (!e.getValueIsAdjusting()) {
                  JList list = (JList)e.getSource();
                  Object[] selected = list.getSelectedValues();
                  String s = "";
                  if(selected.length > 0)
                     s = "" + selected[0];
                  for(Event c : currentComp.getEvents())
                  {  
                     if(c.getName().equals(s))
                     {  
                        for(Skater t : c.getSkaters())
                        {
                           labels2.addElement(t.getName());
                        }
                        currentEvent = c;
                     }
                  }
               }
            }
         }
      }
      private class skaterSelect implements ListSelectionListener {
         public skaterSelect()
         {
         }
         public void valueChanged(ListSelectionEvent e)
         {
            if(currentEvent != null)
            {
               labels3.clear();
               if (!e.getValueIsAdjusting()) {
                  JList list = (JList)e.getSource();
                  Object[] selected = list.getSelectedValues();
                  String s = "";
                  if(selected.length > 0)
                     s = "" + selected[0];
                  for(Skater c : currentEvent.getSkaters())
                  {  
                     if(c.getName().equals(s))
                     {  
                        for(Score t : c.getScores())
                        {
                           labels3.addElement(t.getElement());
                        }
                        currentSkater = c;
                     }
                  }
               }
            }
         }
      }
      private class elsSelect implements ListSelectionListener {
         public elsSelect()
         {
         }
         public void valueChanged(ListSelectionEvent e)
         {
            if(currentSkater != null)
            {
               if (!e.getValueIsAdjusting()) {
                  JList list = (JList)e.getSource();
                  Object[] selected = list.getSelectedValues();
                  String s = "";
                  if(selected.length > 0)
                     s = "" + selected[0];
                  for(Score c : currentSkater.getScores())
                  {  
                     if(c.getElement().equals(s))
                     {  
                        currentScore = c;
                     }
                  }
               }
            }
         }
      }
      private class addJudge implements ActionListener {
         public addJudge()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = JOptionPane.showInputDialog("Enter new Judge's name");
            JOptionPane.showMessageDialog(null, "Default username and pass is first letter of first name + last name. Ask Referee to change password.");
            int space = s.indexOf(" ");
            String user = s.substring(0, 1);
            user+=s.substring(space+1);
            s = checkExistingJudge(judgeArray, s);
            Judge j = new Judge(s, user, user);
            judgeArray.add(j);
            judgeList.addItem(j.getName());
            try{
               myConn.createStatement().execute("INSERT INTO `users` (`username`, `password`, `type`, `name`) VALUES ('" + user.toLowerCase() + "', '" + user.toLowerCase() + "', 'j', '" + s + "')");
            }
               catch (Exception err) { }
         }
      }
      public String checkExistingJudge(ArrayList<Judge> objects, String name){
         boolean exists = false;
         for(int x = 0; x < objects.size(); x++)
         {
            if(objects.get(x).getName().equals(name)){
               exists = true;
            }
         }
         while(exists){
            name = JOptionPane.showInputDialog("That already exists. Try again.");
            exists = false;
            for(int x = 0; x < objects.size(); x++)
            {
               if(objects.get(x).getName().equals(name)){
                  exists = true;
               }
            }
         }
         return name;
      }
      private class addJudgeToEvent implements ActionListener {
      
         public addJudgeToEvent()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = (String)judgeList.getSelectedItem();
            Judge j = null;
            for(Judge a : judgeArray)
            {
               if(a.getName().equals(s))
               {
                  j = a;
               }
            }
            j.addEvent(currentEvent);
         }
      }
      private class viewSelectedEventsList implements ActionListener {
      
         public viewSelectedEventsList()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = (String)judgeList.getSelectedItem();
            Judge j = null;
            for(Judge a : judgeArray)
            {
               if(a.getName().equals(s))
               {
                  j = a;
               }
            }
            String events = j.toString();
            JOptionPane.showMessageDialog(null, events);
         }
      }
      private class changePassword implements ActionListener {
         public changePassword()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            JFrame frame = new JFrame("Change Password");
           
            frame.setLocation(300, 300);
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            JPanel panel = new JPanel();
            frame.setContentPane(panel);
            frame.setVisible(true);
            frame.setSize(300, 150);
            
            oldpass = new JPasswordField(10);
            JLabel askold = new JLabel("Old password: ", SwingConstants.RIGHT);
            JLabel asknew1 = new JLabel ("New password: ", SwingConstants.RIGHT);
            JLabel asknew2 = new JLabel ("Confirm new password: ", SwingConstants.RIGHT);
            newpass1 = new JPasswordField(10);
            newpass2 = new JPasswordField(10);
            
            mid = new JPanel();
            mid.setLayout(new GridLayout(3, 4));
            mid.add(askold);
            mid.add(oldpass);
            JButton changeMe = new JButton ("OK");
            changeMe.setVisible(true);
            changeMe.setEnabled(true);
            JLabel title = new JLabel("Enter new password.");
            changeMe.addActionListener(new ok(frame, title));
            mid.add(new JPanel());
            mid.add(asknew1);
            mid.add(newpass1);
            mid.add(new JPanel());
            mid.add(asknew2);
            mid.add(newpass2);
            mid.add(changeMe);
            panel.add(mid, BorderLayout.CENTER);
         }
      }
      private class ok implements ActionListener {
         public JFrame myFrame;
         public JLabel myTitle;
         public ok(JFrame f, JLabel title)
         {
            myFrame = f;
            myTitle = title;
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = (String)judgeList.getSelectedItem();
            Judge j = null; 
            for(int x = 0; x < judgeArray.size(); x++)
            {
               if(judgeArray.get(x).getName().equals(s)){
                  j = judgeArray.get(x);
               }
            }
            if(j != null){
               try{
                  ResultSet rs = myConn.createStatement().executeQuery("select * from `users` where `username` = '" + j.getUsername1() + "'");  
                  while(rs.next())
                  {
                     if(isSame(j.getPassword(), rs.getString("password").toCharArray()))
                     {
                        if(isSame(newpass1.getPassword(), newpass2.getPassword()))
                        {
                           String r = "";
                           for(int x = 0; x < newpass1.getPassword().length; x++)
                           {
                              r+= newpass1.getPassword()[x];
                           }
                           myFrame.setVisible(false);
                           j.setPassword(r);
                           try{
                              myConn.createStatement().execute("update users set `password`='" + r + "' where username = '" + j.getUsername1() + "'");
                           }
                              catch(Exception err) { }
                        
                        }
                     }
                  }
               }
                  catch(Exception err) { }
            }
         }
      }
      private class removeJudgeFromSelectedEvent implements ActionListener {
         public removeJudgeFromSelectedEvent()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = (String)judgeList.getSelectedItem();
            Judge j = null;
            for(Judge a : judgeArray)
            {
               if(a.getName().equals(s))
               {
                  j = a;
               }
            }
            j.removeEvent(currentEvent);
         }
      }
      private class addComp implements ActionListener { 
      
         public addComp()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = JOptionPane.showInputDialog("Enter name of competition.");
            try{
               ResultSet rs = myConn.createStatement().executeQuery("select * from `competition` WHERE `name` = '" + s + "'");
               while(rs.next())
               {
                  s = JOptionPane.showInputDialog("That competition already exists. Try again.");
                  rs = myConn.createStatement().executeQuery("select * from `competition` WHERE `name` = '" + s + "'");
               }
               compsArray.add(new Competition(s));
               labels.addElement(s);
               myConn.createStatement().execute("INSERT INTO `competition` (`name`) VALUES ('" + s + "')");
            }
               catch (Exception err) { }
         }
      }
      private class removeComp implements ActionListener { 
         public removeComp()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(compsArray.size() >= 1){
               boolean exists = false;
               String s = JOptionPane.showInputDialog("Enter name of competition to remove.");
               int toRemove = -1;  
            
               for(int x = 0; x < compsArray.size(); x++)
               {
                  if(compsArray.get(x).getName().equals(s)){
                     exists = true;
                     toRemove = x;
                  }
               }     
               while(!exists)
               {
                  s = JOptionPane.showInputDialog("That competition does not exist. Try again.");
                  for(int x = 0; x < compsArray.size(); x++)
                  {
                     if(compsArray.get(x).getName().equals(s)){
                        exists = true;
                        toRemove = x;
                     }
                  } 
               }
               labels.remove(toRemove);
               try{
                  myConn.createStatement().execute("delete from `competition` where `name` = '" + compsArray.get(toRemove).getName() + "'");
               }
                  catch (Exception err) { }
               compsArray.remove(toRemove);
               currentComp = null;
            }
            else{
               JOptionPane.showMessageDialog(null, "Please add a competition first");
            }
         }
      }
      private class addEvent implements ActionListener { 
      
         public addEvent()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentComp != null){
               String s = JOptionPane.showInputDialog("Enter event name.");
               s = checkExistingEvent(currentComp.getEvents(), s);
               currentComp.addEvent(new Event(s, currentComp));
               labels1.addElement(s);}
            else{
               JOptionPane.showMessageDialog(null, "Please select a competition first.");
            }
         }
      }
      public String checkExistingEvent(ArrayList<Event> objects, String name){
         boolean exists = false;
         for(int x = 0; x < objects.size(); x++)
         {
            if(objects.get(x).getName().equals(name)){
               exists = true;
            }
         }
         while(exists){
            name = JOptionPane.showInputDialog("That already exists. Try again.");
            exists = false;
            for(int x = 0; x < objects.size(); x++)
            {
               if(objects.get(x).getName().equals(name)){
                  exists = true;
               }
            }
         }
         return name;
      }
   
      private class removeEvent implements ActionListener { 
      
         public removeEvent()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentComp != null){
               if(currentComp.getEvents().size() >= 1)
               {
                  boolean exists = false;
                  String s = JOptionPane.showInputDialog("Enter name of event to remove.");
                  int toRemove = -1; 
                  ArrayList<Event> temp = currentComp.getEvents(); 
               
                  for(int x = 0; x < temp.size(); x++)
                  {
                     if(temp.get(x).getName().equals(s)){
                        exists = true;
                        toRemove = x;
                     }
                  }     
                  while(!exists)
                  {
                     s = JOptionPane.showInputDialog("That event does not exist for this competition. Try again.");
                     for(int x = 0; x < temp.size(); x++)
                     {
                        if(temp.get(x).getName().equals(s)){
                           exists = true;
                           toRemove = x;
                        }
                     } 
                  }
                  labels1.remove(toRemove);
                  currentComp.removeEvent(temp.get(toRemove));
                  currentEvent = null;
               }
               else{
                  JOptionPane.showMessageDialog(null, "Please add events to this competition first.");
               }
            }
         }
      }
      private class addSkater implements ActionListener { 
      
         public addSkater()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentEvent != null){
               String s = JOptionPane.showInputDialog("Enter Skater name.");
               s = checkExistingSkater(currentEvent.getSkaters(), s);
               currentEvent.addSkater(new Skater(s));
               labels2.addElement(s);
            }
            else{
               JOptionPane.showMessageDialog(null, "Please select an event first.");
            }
         }
      }
      public String checkExistingSkater(ArrayList<Skater> objects, String name){
         boolean exists = false;
         for(int x = 0; x < objects.size(); x++)
         {
            if(objects.get(x).getName().equals(name)){
               exists = true;
            }
         }
         while(exists){
            name = JOptionPane.showInputDialog("That already exists. Try again.");
            exists = false;
            for(int x = 0; x < objects.size(); x++)
            {
               if(objects.get(x).getName().equals(name)){
                  exists = true;
               }
            }
         }
         return name;
      }
      private class logout implements ActionListener {
         public logout()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            try{
               myConn.createStatement().execute("truncate table scores");
               myConn.createStatement().execute("delete from skaters where `id` < 1000000");
               myConn.createStatement().execute("delete from judge_events where `judge_id` < 1000000");
               myConn.createStatement().execute("delete from events where `id` < 1000000"); 
            }
               catch (Exception err) {  }
            for(Competition c : compsArray)
            {
               for(Event ev : c.getEvents())
               {
                  try{
                     myConn.createStatement().execute("insert into `events` (`name`, `competition_id`) select '" + ev.getName() + "', `id` from competition where `competition`.`name`='" + c.getName() + "'");
                  }
                     catch (Exception err) { }
                  for( Skater s : ev.getSkaters())
                  {
                     try{
                        myConn.createStatement().execute("insert into `skaters` (`name`, `final_score`, `event_id`) select '" + s.getName() + "', '" + s.getScore() + "', `id` from events where `events`.`name`='" + ev.getName() + "'");
                     }
                        catch (Exception err) { } 
                     for(Score sc : s.getScores())
                     {
                        try{
                           myConn.createStatement().execute("insert into `scores` (`element_name`, `score`, `skater_id`) select '" + sc.getElement() + "', '" + sc.getScore() + "', `id` from skaters where `skaters`.`name`='" + s.getName() + "'");
                        }
                           catch (Exception err) { }
                     }
                  }
               }
            }
           //put judges' events into databases
            for(Judge j : judgeArray)
            {
               try{
                  for(Event v : j.getEvents())
                  {
                     int cid = -1;
                     int eid = -1;
                     int jid = -1;
                     ResultSet compID = myConn.createStatement().executeQuery("select `id` from competition where `name` = '" + v.getComp().getName() + "'");
                     while(compID.next())
                     {
                        cid = compID.getInt("id");
                     }
                     ResultSet eventID = myConn.createStatement().executeQuery("select `id` from events where `name` = '" + v.getName() + "' and `competition_id`=" + cid);
                     while(eventID.next())
                     {
                        eid = eventID.getInt("id");
                     }
                     ResultSet judgeID = myConn.createStatement().executeQuery("select `id` from users where `name` = '" + j.getName() + "'");
                     while(judgeID.next())
                     {
                        jid = judgeID.getInt("id");
                     }
                  
                  
                   		
                  /*insert into judge_events (`judge_id`, `event_id`) (select `users`.`id`, `events`
                  .`id` from `users`, `events` where users.username='kcolen' AND events.name='int
                  ladies long' AND events.competition_id = 17)*/
                     myConn.createStatement().execute("insert into `judge_events` (`judge_id`, `event_id`) VALUES (" + jid + ", " + eid + ")");
                  }
               }
                  catch(Exception err) { }
            }
            login();
         }
      }
      private class removeSkater implements ActionListener { 
      
         public removeSkater()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentEvent != null){
               
               if(currentEvent.getSkaters().size() >=1)
               {
                  boolean exists = false;
                  String s = JOptionPane.showInputDialog("Enter name of skater to remove.");
                  int toRemove = -1; 
                  ArrayList<Skater> temp = currentEvent.getSkaters(); 
                  
                  for(int x = 0; x < temp.size(); x++)
                  {
                     if(temp.get(x).getName().equals(s)){
                        exists = true;
                        toRemove = x;
                     }
                  }     
                  while(!exists)
                  {
                     s = JOptionPane.showInputDialog("That skater does not exist for this event. Try again.");
                     for(int x = 0; x < temp.size(); x++)
                     {
                        if(temp.get(x).getName().equals(s)){
                           exists = true;
                           toRemove = x;
                        }
                     } 
                  }
                  labels2.remove(toRemove);
                  currentEvent.removeSkater(temp.get(toRemove));
                  currentSkater = null;
               }
               else{
                  JOptionPane.showMessageDialog(null, "Please add skaters to this event first.");
               }
               
            }
         }
      }
      private class addEls implements ActionListener { 
      
         public addEls()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentSkater != null){
               String s = JOptionPane.showInputDialog("Enter element code.");
               while (!base.containsKey(s))
               {
                  s = JOptionPane.showInputDialog("Invalid element. Try again. What element?");
               }
               currentSkater.addScore(new Score(s));
               labels3.addElement(s);
            }
            else{
               JOptionPane.showMessageDialog(null, "Please select a skater first.");
            }
         }
      }
      private class removeEls implements ActionListener { 
      
         public removeEls()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            if(currentSkater != null){
               
               if(currentSkater.getScores().size() >=1)
               {
                  boolean exists = false;
                  String s = JOptionPane.showInputDialog("Enter element to remove.");
                  int toRemove = -1; 
                  ArrayList<Score> temp = currentSkater.getScores(); 
                  
                  for(int x = 0; x < temp.size(); x++)
                  {
                     if(temp.get(x).getElement().equals(s)){
                        exists = true;
                        toRemove = x;
                     }
                  }     
                  while(!exists)
                  {
                     s = JOptionPane.showInputDialog("That element does not exist for this skater. Try again.");
                     for(int x = 0; x < temp.size(); x++)
                     {
                        if(temp.get(x).getElement().equals(s)){
                           exists = true;
                           toRemove = x;
                        }
                     } 
                  }
                  labels3.remove(toRemove);
                  currentSkater.removeScore(temp.get(toRemove));
               }
               else{
                  JOptionPane.showMessageDialog(null, "Please add elements this skater plans to perform first.");
               }
               
            }
         }
      }
      public boolean isSame(char[] a, char[] b)
      {
         if(a.length != b.length){
            return false;
         }
         else{
            for(int x = 0; x < a.length; x++)
            {
               if(!("" + a[x]).equals("" + b[x])){
                  return false;
               }
            }
         }
         return true;
      }
      private class go implements ActionListener {
         public go()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String s = username.getText();
            try{
               ResultSet rs = myConn.createStatement().executeQuery("select * from `users` where `username` = '" + s + "'"); 
               while(rs.next())
               {
                  if(isSame(pass.getPassword(), rs.getString("password").toCharArray()))
                  {
                     if(rs.getString("type").equals("r"))
                     {
                        refereePanel();
                     }
                     else if(rs.getString("type").equals("j"))
                     {
                        Judge currentJudge = new Judge();
                        for(Judge j : judgeArray)
                        {
                           if(j.getName().equals(rs.getString("name")))
                           {
                              currentJudge = j;
                           }
                        }
                        ArrayList<String> compsList = new ArrayList<String>();
                        for(Event ev : currentJudge.getEvents())
                        {
                           if(!compsList.contains(ev.getComp().getName()))
                           {
                              compsList.add(ev.getComp().getName());
                           }
                        }
                        comps = (String[])(compsList.toArray(new String[compsList.size()]));
                        
                        judgePanel();
                     }
                  }
                  else
                  {
                     title.setText("Invalid login. Try Again.");
                     pass.selectAll();
                     resetFocus();
                  }
               }
            }
               catch(Exception err) { }
         }
         protected void resetFocus() {
            pass.requestFocusInWindow();
         }
      }
      
      private class instructions implements ActionListener {
         public instructions()
         {
         }
         public void actionPerformed(ActionEvent e)
         {
            String message = "Choose one score for the artistic component of the score and one GOE for each element the skater performs. The \n computer will autmoatically calculate the score and rank the skaters once all have performed.";
            JOptionPane.showMessageDialog(null, message);
         }
      }
      public void getBV() throws FileNotFoundException
      {
         Scanner infile = new Scanner(new File("SOV.txt"));
         while(infile.hasNext()){
            String temp = infile.nextLine();
            String el = temp.substring(0, temp.indexOf(" "));
            double score = Double.parseDouble(temp.substring(temp.indexOf(" ")));
            base.put(el, score);
         }
      } 
      private class Handler implements ActionListener
      {
         private int myScore;
          
         public Handler(int r)
         {
            myScore = r;
         }
         public void actionPerformed(ActionEvent e)
         {
            currentSkater.setArtistic(myScore);
            String current = "Artistic: " + myScore;
            for(Score s : currentSkater.getScores())
            {
               current += "\n" + s.getElement() + "\t \t" + s.getScore();
            }
            current += "\n\n" + "Are these scores correct? You will not be able to \n change these scores once you say yes. Press 1 if these scores are correct \n and 2 if you need to make changes.";
            String changeMe = JOptionPane.showInputDialog(current);
            if(changeMe.equals("1")){
            }
            else if(changeMe.equals("2")){
               changeScores();
            }
            for(JButton j : abuttons)
            {
               j.setEnabled(false);
            }
            for(JButton j : tbuttons)
            {
               j.setEnabled(true);
            }
            if(currentSkater != currentEvent.getSkaters().get(currentEvent.getSkaters().size()-1))
            {
               int curSkater = -1;
               Skater tempCur = null;
               for(int x = 0; x < currentEvent.getSkaters().size(); x++)
               {
                  if(currentSkater == currentEvent.getSkaters().get(x))
                  {
                     curSkater = x;
                     tempCur = currentEvent.getSkaters().get(x+1);
                  }
               }
               cSkater.setText("Skater number: " + (curSkater+2));
               currentSkater = tempCur;
               cEl.setText("Element number: 1");
               curScore = 0;
               String s = "";
               for(int x = 0; x < currentSkater.getScores().size(); x++)
               {
                  s += (x+1) + ". " + currentSkater.getScores().get(x).getElement() + "\n";
               }
               elsList.setText(s);
            }
            else{
               JOptionPane.showMessageDialog(null, "All skaters have performed. Computer will automatically rank the skaters.");
               rank();
               String rankings = "FINAL RANKINGS: \n";
               for(int x = 0; x < ranks.size(); x++)
               {
                  rankings += (x+1) + ". " + ranks.get(x).getName() + "\t \t \t" + ranks.get(x).getScore() + "\n";
               }
               eventList.setEnabled(false);
               elsList.setText("");
               skatersList.setText("");
               for(JButton j : abuttons)
               {
                  j.setEnabled(false);
               }
               for(JButton j : tbuttons)
               {
                  j.setEnabled(false);
               }
               JOptionPane.showMessageDialog(null, rankings);
               
            }
         }
      
         public void changeScores(){
            int contAsk = 0;
            while(contAsk != -1){
               String ask = "What score is wrong? Enter a number corresponding to the incorrect score. Enter -1 to finish. \n" ;
               ask += "Artistic (enter 0): " + myScore;
               int elNum = 1;
               for(Score s : currentSkater.getScores())
               {
                  ask += "\n" + elNum + ". " + s.getElement() + "\t \t" + s.getScore();
                  elNum+=1;
               }
               contAsk = Integer.parseInt((JOptionPane.showInputDialog(ask)));
               if (contAsk != -1){
                  int newScore = Integer.parseInt((JOptionPane.showInputDialog("Enter corrected score.")));
                  if(contAsk > 1){
                     currentSkater.getScores().get(contAsk-1).setScore(newScore);
                  }
                  else{
                     currentSkater.setArtistic(newScore);
                  }
               }
            }
         }
      }
      private class Handler1 implements ActionListener
      {
         private int myScore;
         public Handler1(int r)
         {
            myScore = r;
         }
         public void actionPerformed(ActionEvent e)
         {
            if(curScore == (currentSkater.getScores().size() - 1))
            {
               for(int x = 1; x < 11; x++)
               {
                  abuttons.get(x-1).setEnabled(true);
               }
               for(int x = -3; x < 4; x++)
               {
                  tbuttons.get(x+3).setEnabled(false);
               }
               currentSkater.getScores().get(curScore).setScore(myScore);
               techScores = new ArrayList<Integer>();
            }
            else
            {
               curScore += 1;
               cEl.setText("Element Number: " + (curScore+1));
            }
         }
      }
      public void rank()
      {
         for(Skater s : currentEvent.getSkaters())
         {
            double inte = s.getFinal(base);
            finalScores.put(inte, s);
         }
         double max = 0;
         Skater maxSkater = new Skater();
         while(!finalScores.isEmpty())
         {
            for(double d : finalScores.keySet())
            {
               if (d > max)
               {
                  max = d;
                  maxSkater = finalScores.get(d);
               }
            }
            ranks.add(maxSkater);
            finalScores.remove(max);
            max = 0;   
         }
      }
   }