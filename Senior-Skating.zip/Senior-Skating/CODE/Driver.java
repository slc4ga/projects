//Stephanie Colen

   import javax.swing.JFrame;
   import javax.swing.*;
   import java.awt.*;
   import java.awt.event.*;
   import java.io.*;
   import java.util.*;
   import java.sql.*;
   public class Driver 
   {
      public static void main(String[] args) throws FileNotFoundException
      {
         Connection conn = null;
         try {
         // Set System L&F
            UIManager.setLookAndFeel(
               UIManager.getSystemLookAndFeelClassName());
         } 
            catch (UnsupportedLookAndFeelException e) {
            // handle exception
            }
            catch (ClassNotFoundException e) {
            // handle exception
            }
            catch (InstantiationException e) {
            // handle exception
            }
            catch (IllegalAccessException e) {
            // handle exception
            }
         try{
            Class.forName("org.gjt.mm.mysql.Driver"); //Load the driver
            conn = DriverManager.getConnection("jdbc:mysql://localhost/data", "root", ""); //Connect
         }
            catch (Exception err){
               System.out.println("" + err);
            }
      
         JFrame frame = new JFrame("SKATE");
         frame.setSize(700,300);
         frame.setLocation(200, 100);
         frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
         Panel1 panel = new Panel1(frame, conn);
         frame.setContentPane(panel);
         frame.setIconImage(new ImageIcon("icon.jpg").getImage());
         frame.setVisible(true);
      	
      	
      }
   }