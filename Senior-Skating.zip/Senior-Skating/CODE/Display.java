//Stephanie Colen
   import javax.swing.*;
   import java.awt.*;
   import java.util.*;
   import java.awt.event.*;
   import java.io.*;
   
   public class Display extends JPanel  
   {
      //private Scanner infile;
		private ArrayList<JButton> artistic;
   
      public Display(/*Scoreboard scoreboard*/)
      {
        artistic  = new ArrayList<JButton>();   
		  for(int x = 1; x < 10; x++)
		  {
		  artistic.add(new JButton("" + x));
		  artistic.get(x).setEnabled(true);
		  artistic.get(x).setBackground(Color.RED);
		  }
		   
	   }
   }