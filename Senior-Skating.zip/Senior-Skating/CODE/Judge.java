//Stephanie Colen

   import java.util.*;
   import java.io.*;
   
   public class Judge
   {
      private ArrayList<Event> myEvents = new ArrayList<Event>();
      private String myName;
      private char[] myUsername;
      private char[] myPass;
   
   
      public Judge()
      {
         myName = "";
      }
      public Judge(String s, ArrayList<Event> e)
      {
         myName = s;
         myEvents = e;
      }
      public Judge(String s, String username, String pass)
      {
         myName = s;
         myUsername = username.toCharArray();
         myPass = pass.toCharArray();
      }
      public String getName()
      {
         return myName;
      }
      public ArrayList<Event> getEvents()
      {
         return myEvents;
      }
      public void addEvent(Event e)
      {
         myEvents.add(e);
      }
      public char[] getUsername(){
         return myUsername;
      }
      public String getUsername1(){
         String s = "";
         for(int x = 0; x < myUsername.length; x++)
         {
            s+= myUsername[x];
         }
         return s;
      }
      public void setName(String s)
      {
         myName = s;
      }
      public void setPassword(String s){
         myPass = s.toCharArray();
      }
      public char[] getPassword(){
         return myPass;
      }
      public String toString() 
      {
         String events = myName + "\n\n";
         for(int x = 0; x < myEvents.size(); x++)
         {
            events += (x+1) + ". " + myEvents.get(x).getName() + "\n";
         }
         return events;
      }
      public void removeEvent(Event e)
      {
         int toRemove = -1;
         for(int x = 0; x < myEvents.size(); x++)
         {
            if(e.getName().equals(myEvents.get(x).getName()))
            {
               toRemove = x;
            }
         }
         myEvents.remove(toRemove);
      }
   
   }