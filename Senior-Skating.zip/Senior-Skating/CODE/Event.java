//Stephanie Colen 

   import java.util.*;
   import java.io.*;


   public class Event {
   
      private String name;
      private Competition myComp;
      private ArrayList<Skater> skaters = new ArrayList<Skater>();
   
      public Event(){
         name = "";
      }
      public Event(String n, Competition c){
         name = n;
         myComp = c;
      }
      public Event(String n, ArrayList<String> s){
         name = n;
         for(String element : s){
            skaters.add(new Skater(element));
         }	
      }
      public String getName(){
         return name;
      }
      public ArrayList<Skater> getSkaters(){
         return skaters;
      }
      public void setName(String n){
         name = n;
      }
      public void setSkaters(ArrayList<String> s){
         for(String element : s){
            skaters.add(new Skater(element));
         }
      }
      public String toString(){
         String temp = "";
         for(Skater s : skaters)
         {
            temp = temp + s.getName();
         }
         return name + ": " + temp;
      }
      public void addSkater(Skater s){
         skaters.add(s);
      }
      public void removeSkater(Skater e)
      {
         int toRemove = -1;
         for(int x = 0; x < skaters.size(); x++)
         {
            if(e.getName().equals(skaters.get(x).getName()))
            {
               toRemove = x;
            }
         }
         skaters.remove(toRemove);
      }
      public void setComp(Competition c)
      {
         myComp = c;
      }
      public Competition getComp()
      {
         return myComp;
      }
   
   }