   import java.sql.*;
   public class SQLProject{
      public static void main (String[] args){
         try{
            Class.forName("org.gjt.mm.mysql.Driver"); //Load the driver
            Connection conn = DriverManager.getConnection("jdbc:mysql://localhost/data", "root", ""); //Connect
         }
            catch (Exception err){
               System.out.println("" + err);
            }
      }
   }
